This is the content of the batch-response.tar.gz file,
to create the file execute:

`tar -zcvf test/integration/fixtures/batch-response.tar.gz test/integration/fixtures/batch-response`
